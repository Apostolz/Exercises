﻿using NUnit.Framework;
using ObjectModelHomework.Pages;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System.IO;
using System.Reflection;


namespace OObjectModelHomework.Pages
{
    [TestFixture]
    public class QAAutomation
    {
        private ChromeDriver _driver;
        private LoginPage _loginPage;
        private TestObjectsPage _regPage;
        private TestObjectsPage _search;

        [SetUp]
        public void SetUp()
        {
            _driver = new ChromeDriver(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location));
            _driver.Manage().Window.Maximize();
            _loginPage = new LoginPage(_driver);
            _regPage = new TestObjectsPage(_driver);
            _search = new TestObjectsPage(_driver);

        }

        [Test]
        public void QACourse()
        {
            _loginPage.NavigateSoftUni(_loginPage);
            _regPage.SearchForQACourse(_search);
            _regPage.AssertHeader("QA Automation - септември 2019");
        }

        [TearDown]
        public void TearDown()
        {
            // _driver.Quit();
        }
    }
}
