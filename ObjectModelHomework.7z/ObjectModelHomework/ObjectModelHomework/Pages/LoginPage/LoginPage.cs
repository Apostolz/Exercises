﻿using OpenQA.Selenium;

namespace ObjectModelHomework.Pages
{
    public class LoginPage : BasePage
    {
        public LoginPage(IWebDriver driver)
            : base(driver)
        {
        }
        //SeleniumBasics
        public void NavigateGoogle(LoginPage loginPage)
        {
            loginPage.NavigateGoogle("https://www.google.com/");
        }

        //QAAutomation
        public void NavigateSoftUni(LoginPage coursePage)
        {
            coursePage.NavigateSoftUni("https://www.softuni.bg/");
        }

        //RegistrationUser
        public string Url => "http://automationpractice.com/index.php?controller=my-account";

        public IWebElement Email => Driver.FindElement(By.Id("email_create"));

        public IWebElement Submit => Driver.FindElement(By.Id("SubmitCreate"));

    }
}
