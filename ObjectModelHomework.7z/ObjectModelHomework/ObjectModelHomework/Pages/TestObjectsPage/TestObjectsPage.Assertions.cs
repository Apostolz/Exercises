﻿using NUnit.Framework;

namespace ObjectModelHomework.Pages
{
    public partial class TestObjectsPage
    {
        //SeleniumBasics
        public void AssertTitle(string expected)
        {
            Assert.AreEqual(expected, Driver.Title);
        }

        //QAAutomation
        public void AssertHeader(string expected)
        {
            Assert.AreEqual(expected, header.Text);
        }


        //RegistrationUser
        public void AssertErrorMessage(string expected)
        {
            Assert.AreEqual(expected, Error.Text);
        }

    }
}
