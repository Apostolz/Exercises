﻿using ObjectModelHomework.Extensions;
using OpenQA.Selenium;

namespace ObjectModelHomework.Pages
{
    public partial class TestObjectsPage
        
    {

        public void SearchForSelenium(TestObjectsPage _fill)
        {
            //SeleniumBasics
            searchInput.Type("Selenium");
            logo.Click();
            searchButton.Click();
            seleniumResult.Click();
        }

        public void SearchForQACourse(TestObjectsPage _search)
        {
  
            //QAAutomation
            courses.Click();
            qaCourseLink.Click();

        }

        //RegistrationUser

        public void FillForm(RegistrationUserSetting user)
        {
            
            CustomerFirstName.SendKeys(user.FirstName);
            CustomerLastName.SendKeys(user.LastName);
            RadioButtons[0].Click();
            Password.SendKeys(user.Password);
            Days.SelectByValue(user.Date);
            Months.SelectByValue(user.Month);
            Years.SelectByValue(user.Year);
            Address.SendKeys(user.Address);
            City.SendKeys(user.City);
            State.SelectByText(user.State);
            PostCode.SendKeys(user.PostCode);
            Phone.SendKeys(user.Phone);
            Alias.SendKeys(user.Alias);
            RegisterButton.Click();
        }

        public void Navigate(LoginPage loginPage)
        {
            loginPage.Navigate("http://automationpractice.com/index.php?controller=my-account");

            loginPage.Email.SendKeys("djburoooooooooo11ooo@gmail.com");
            loginPage.Submit.Click();
        }

    }
}
