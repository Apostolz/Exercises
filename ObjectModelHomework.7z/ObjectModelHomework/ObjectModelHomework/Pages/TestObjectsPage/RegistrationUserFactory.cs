﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ObjectModelHomework.Pages
{
    public static class RegistrationUserFactory 
    {
        public static RegistrationUserSetting CreateUser()
        {
            return new RegistrationUserSetting
            {
                FirstName = "DDD",
                LastName = "AAA",
                Gender = "male",
                Password = "ghghghhg",
                Date = "9",
                Month = "9",
                Year = "1981",
                Address = "Pripqt",
                City = "Sofia",
                State = "Arizona",
                PostCode = "00501",
                Phone = "4899658",
                Alias = "bananas"
                








            };
        }

    }
}
