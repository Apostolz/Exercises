﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;


namespace ObjectModelHomework.Pages
{
   
    public abstract class BasePage
    {
        private IWebDriver driver;
        private WebDriverWait _wait;

        public BasePage(IWebDriver driver)
        {
            this.driver = driver;
            _wait = new WebDriverWait(this.driver, TimeSpan.FromSeconds(30));
        }

        public IWebDriver Driver => driver;

        public WebDriverWait Wait => _wait;

        public virtual void NavigateGoogle(string url)
        {
            Driver.Url = url;
        }

        public virtual void NavigateSoftUni(string url)
        {
            Driver.Url = url;
        }

        public virtual void Navigate(string url)
        {
            Driver.Url = url;
        }
    }
}
