﻿using NUnit.Framework;
using OpenQA.Selenium.Chrome;
using System.IO;
using System.Reflection;


namespace ObjectModelHomework.Pages
{
    [TestFixture]
    public class SeleniumBasics
    {

        private ChromeDriver _driver;
        private LoginPage _loginPage;
        private TestObjectsPage _regPage;
        private TestObjectsPage _fill;
      
        [SetUp]
        public void SetUp()
        {
            _driver = new ChromeDriver(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location));
            _driver.Manage().Window.Maximize();
            _loginPage = new LoginPage(_driver);
            _regPage = new TestObjectsPage(_driver);
            _fill = new TestObjectsPage(_driver);

        }

        [Test]
        public void SeleniumCheck()
        {
            _loginPage.NavigateGoogle(_loginPage);
            _regPage.SearchForSelenium(_fill);
            _regPage.AssertTitle("Selenium - Web Browser Automation");

        }

        [TearDown]
        public void TearDown()
        {
           // _driver.Quit();
        }
    }
}
