﻿using NUnit.Framework;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Text;

namespace ObjectModelHomework.Pages

{
    [TestFixture]
    class RegistrationUser
    {


        private LoginPage _loginPage;
        private TestObjectsPage _regPage;
        private RegistrationUserSetting _user;
        private ChromeDriver _driver;

        [SetUp]
        public void CalssInit()
        {
            _driver = new ChromeDriver(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location));
            _driver.Manage().Window.Maximize();
            _driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(10);

            _loginPage = new LoginPage(_driver);
            _regPage = new TestObjectsPage(_driver);

            _user = RegistrationUserFactory.CreateUser();
        }

      

        [Test]
        public void FillRegistrationFormWithoutFirstName()
        {
            _user.Phone = "";
            _regPage.Navigate(_loginPage);
            _regPage.FillForm(_user);
            _regPage.AssertErrorMessage("You must register at least one phone number.");
        }

        [Test]
        public void FillRegistrationFormWithoutFirsPhone()
        {
            _user.FirstName = "";
            _regPage.Navigate(_loginPage);
            _regPage.FillForm(_user);
            _regPage.AssertErrorMessage("firstname is required.");
        }

        [Test]
        public void FillRegistrationFormWithoutLastName()
        {
            _user.LastName = "";
            _regPage.Navigate(_loginPage);
            _regPage.FillForm(_user);
            _regPage.AssertErrorMessage("lastname is required.");
        }

        [TearDown]
        public void TearDown()
        {
            // _driver.Quit();
        }
    }   
}
