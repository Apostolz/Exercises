﻿using NUnit.Framework;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Remote;
using System;


namespace ObjectModelHomework.Pages
{
    [TestFixture]
    public class TestGrid
    {

        private RemoteWebDriver _driver;
        private LoginPage _loginPage;
        private TestObjectsPage _regPage;
        private TestObjectsPage _fill;

        [SetUp]
        public void SetUp()
        {
            ChromeOptions options = new ChromeOptions();
            options.PlatformName = "windows";
            options.BrowserVersion = "77.0";

            _driver = new RemoteWebDriver(new Uri("http://192.168.8.65:4444/wd/hub"), options.ToCapabilities(), TimeSpan.FromSeconds(10));
            _driver.Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(30);
            _loginPage = new LoginPage(_driver);
            _regPage = new TestObjectsPage(_driver);
            _fill = new TestObjectsPage(_driver);

        }

        [Test]
        public void SeleniumCheck()
        {
            _loginPage.NavigateGoogle(_loginPage);
            _regPage.SearchForSelenium(_fill);
            _regPage.AssertTitle("Selenium - Web Browser Automation");

        }

        [TearDown]
        public void TearDown()
        {
             _driver.Quit();
        }
    }
}
